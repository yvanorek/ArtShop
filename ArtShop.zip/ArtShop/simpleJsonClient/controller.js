$(document).ready(function () {
    // Navbar wird geladen
    $("#navbar-placeholder").load("/ArtShop/simpleJsonClient/config/navbar.php", function() {
        // Nachdem die Navbar geladen wurde, binden Sie den Event-Handler an den Warenkorb-Link
        $('#product-search').on('input', function () {
            var searchTerm = $(this).val();
            if (searchTerm.length > 0) {
                searchProducts(searchTerm);
            }
        });
    });

    
/*
    $('a[href$="/ArtShop/simpleJsonClient/config/warenkorb.html"]').on('click', function(e) {
        console.log("dddddddddddddddddddddd");
        // Verhindern Sie das Standardverhalten des Links, damit AJAX funktionieren kann
        e.preventDefault();
        
        // Führen Sie die updateCartItems Funktion aus
        updateCartItems();
        
        // Optional: navigieren Sie zur Warenkorbseite, wenn die Aktualisierung abgeschlossen ist
        window.location.href = '/ArtShop/simpleJsonClient/config/warenkorb.html';
         //location.href = this.href;
    });
   */ 


   
    // Laden weiterer Inhalte
    updateCartItems();
    updateCartCount();
    loadCategories(); // Lädt die Kategorien, wenn die Seite fertig geladen ist
});


$(document).on('click', '#cartlink', function(e){
    e.preventDefault();
    window.location.href = this.href;
    updateCartItems();
    //window.location.href = this.href;
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//DISPLAY WEBSHOP///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function loadCategories() {
        $.ajax({
            url: '/ArtShop/getCategories.php',
            type: 'GET',
            dataType: 'json',
            success: function (categories) {
                console.log(categories);
                categories.forEach(function (category) {
                    console.log(category);
                    $('#categories').append(
                        $('<button></button>')
                            .addClass('category-btn')
                            .text(category.Bezeichnung)
                            .text(category.Bezeichnung)
                            .click(function () {
                                loadProducts(category.KatID);                                               //ACHTUNG HIER IST EIN FILTER für kat
                                console.log(category.KatID);
                            })
                    );
                    $('#categories .category-btn:first').click();
                });
            }
        });
    }

    function loadProducts(categoryId) {
        $.ajax({
            url: '../getProducts.php',
            type: 'GET',
            data: { category_id: categoryId },
            dataType: 'json',
            success: function (products) {
                displayProducts(products); // Nutzt die gemeinsame Funktion zum Anzeigen der Produkte
            }
        });
    }

    function displayProducts(products) {
        console.log("inProducts");
        console.log(products);
        $('#products').empty();     // Löscht vorherige Produkte, bevor neue geladen werden
        products.forEach(function (product) {
            console.log(product);
            var productDiv = $('<div class="product"></div>').html(
                '<img src="' + product.Bildpfad + '" alt="' + product.Name + '">' +
                '<h4>' + product.Bezeichnung + '</h4>' +
                '<span>' + product.Preis.toFixed(2).replace('.', ',') + ' Euro</span>'
            );
            var cartButton = $('<button>In den Warenkorb</button>')
                .click(function () {
                    addToCart(product.PID); // 'pid' ist die Eigenschaft, die das Produkt eindeutig identifiziert
                });
            productDiv.append(cartButton); // Fügt den Button zum Produkt-Div hinzu
            $('#products').append(productDiv); // Fügt das gesamte Produkt-Div zum Produkten-Container hinzu
        });
    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//PRODUKTSUCHE///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    function searchProducts(searchTerm) {
        $.ajax({
            url: '../searchProducts.php', // Pfad zu  Such-Script
            type: 'GET',
            data: { term: searchTerm },
            dataType: 'json',
            success: function (products) {
                //  aktualisieren der Produktansicht mit den Suchergebnissen
                console.log("Suchergebnisse: ", products);
                displayProducts(products); 
            },
            error: function (xhr, status, error) {
                // Fehlerbehandlung, wenn die AJAX-Anfrage fehlschlägt
                console.error("Suchfehler: ", status, error);
            }
        });
    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//WARENKORB///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function addToCart(productId) {
        $.ajax({
            url: '../addToCart.php',
            type: 'POST',
            data: { product_id: productId },
            success: function (response) {
                
                updateCartCount();
                updateCartItems();
            }
        });
    }

    function updateCartCount() {
        $.ajax({
            url: '/ArtShop/cartCount.php',
            type: 'GET',
            success: function (count) {
                $('#cart-count').text(count); 
            }
        });
    }


   
    
    

    

    function updateCartItems() { 
        console.log("aaaaaaaaa");
        $.ajax({
            url: '/ArtShop/getCartItems.php', // Pfad zum PHP-Skript, das die Warenkorbdaten zurückgibt
            type: 'GET',
            dataType: 'json',
            success: function (cartItems) {
                console.log("hhhhhhhhhhhhhhhhhhhhhh");
                console.log(cartItems);
                console.log(cartItems.length);
                console.log("weiterleitung zu warenkorb");
                //window.location.href = '/ArtShop/simpleJsonClient/config/warenkorb.html';
                if(cartItems.length === 0) {
                    $('#cart-items').html('<p>Ihr Warenkorb ist leer.</p>');
                } else {
                    var tableBody = $('#cartTable tbody');
                    cartItems.forEach(function(item) {
                        
                            var row = $('<tr>');
                            row.append($('<td>').text(item.PID));
                            row.append($('<td>').text(item.Bezeichnung));
                            row.append($('<td>').text(item.Menge));
                            row.append($('<td>').text(item.Preis));
                            row.append($('<td>').text((item.Preis*item.Menge).toFixed(2)));
                            tableBody.append(row);
            
                        });



                
                }
                // Update cart total etc.
                
            },
            error: function (request, status, error) {
                $('#cart-items').html('<p>Es gab ein Problem beim Laden des Warenkorbs.</p>');
                console.error('Error fetching cart items:', error);
            }
        });
    }


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//REGISTRIERUNG///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




document.addEventListener('DOMContentLoaded', function() {
    var registrationForm = document.getElementById('registrationForm');
    registrationForm.addEventListener('submit', function(e) {
        e.preventDefault();
        var formData = new FormData(registrationForm);
        var password = formData.get('password');
        var confirm_password = document.getElementById('confirm_password').value;

        if (password !== confirm_password) {
            alert('Passwörter stimmen nicht überein!');
            return;
        }

        fetch('/ArtShop/register.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Registrierung erfolgreich!');
                
            } else {
                alert('Fehler: ' + data.message); // Zeigt Alert mit der Fehlermeldung
            }
        })
        .catch(error => {
            console.error('Fehler: ', error);
            alert('Ein technischer Fehler ist aufgetreten. Bitte versuchen Sie es später noch einmal.');
        });
    });
});



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//LOGIN///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



document.addEventListener('DOMContentLoaded', function() {
    // Bindet das Formular-Submit-Event an die AJAX-Funktion
    var loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.onsubmit = function(e) {
            e.preventDefault(); // Stoppt die normale Formularübermittlung
            var formData = new FormData(this);

            // Führt die AJAX-Anfrage aus
            fetch('/ArtShop/login.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Verarbeitet die erfolgreiche Anmeldung
                    console.log('Erfolgreich eingeloggt');

                    /*
                     // Update der Login-Link zu Logout
                    var loginLink = document.getElementById('loginLink');
                    loginLink.textContent = 'Logout';
                    $('#categories').append('<a href="/logout.php">Logout</a>');
                    */
                    window.location.href = '/ArtShop/simpleJsonClient/index.html';
                    // Dynamisch den Logout-Button anzeigen oder das Menü ändern
                    // ...
                } else {
                    // Fehlermeldung anzeigen
                    alert('Login fehlgeschlagen: ' + data.error);
                    
                }
            })
            .catch(error => {
                console.error('Fehler bei der Anfrage: ', error);
                alert('Ein Fehler ist aufgetreten. Bitte versuchen Sie es später noch einmal.');
            });
        };
    }
});


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//MEIN KONTO///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                                                                            /// gehört das hier oder muss man den teil einfach ganz oben beim ready einbauen?
$(document).ready(function () {
    // Profilinformationen laden
    loadProfile();

    // Event-Listener für Formular-Submit
    $('#profileForm').on('submit', function (e) {
        e.preventDefault();
        updateProfile();
    });

    // Bestellhistorie laden
    //loadOrderHistory();
});

function loadProfile() {
    $.ajax({
        url: '/ArtShop/getProfile.php', // Der Pfad zu  PHP-Script, das die Profilinformationen lädt
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            if (response.success) {
                $('#vorname').val(response.data.Vorname);
                $('#nachname').val(response.data.Nachname);
                $('#adresse').val(response.data.Adresse);
                $('#plz').val(response.data.Plz);
                $('#ort').val(response.data.Ort);
                $('#email').val(response.data.Mail);
                //$('#username').val(response.data.Username);
                $('#zahlungsinformation').val(response.data.Zahlungsinformation);
            } else {
                console.error('Profil konnte nicht geladen werden:', response.error);
            }
        },
        error: function (xhr, status, error) {
            console.error('Ein Fehler ist aufgetreten:', error);
        }
    });
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//MEIN KONTO ÄNDERUNGEN///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



function updateProfile() {
    var formData = $('#profileForm').serialize(); // Sammelt die Formulardaten
    console.log(formData);
    $.ajax({
        url: '/ArtShop/updateProfile.php', // Der Pfad zu  PHP-Script, das die Aktualisierungen speichert
        type: 'POST',
        data: formData,
        dataType: 'json',
        success: function (response) {
            if (response.success) {
                alert('Profil erfolgreich aktualisiert.');
            } else {
                alert('Fehler beim Aktualisieren des Profils: ' + response.error);
            }
        },
        error: function (xhr, status, error) {
            alert('Ein Fehler ist aufgetreten: ' + error);
        }
    });
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////KUNDENSTAMM ANZEIGEN///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



$(document).ready(function() {
    loadCustomers();

    $('#customerTable').on('click', '.deactivate-button', function() {
        var userId = $(this).data('id');
        console.log($(this).data('id'));
        deactivateUser(userId);
    });
});

function loadCustomers() {
    $.ajax({
        url: '/ArtShop/getCustomers.php',
        type: 'GET',
        dataType: 'json',
        success: function(data) {
            var rows = '';
            data.forEach(function(customer) {
                rows += `<tr>
                            <td>${customer.KID}</td>
                            <td>${customer.Benutzername}</td>
                            <td>${customer.Inaktiv == 1 ? 'Deaktiviert' : 'Aktiv'}</td>
                            <td><button data-id="${customer.KID}" class="deactivate-button">${customer.Inaktiv == 1 ? 'Aktivieren' : 'Deaktivieren'}</button></td>
                        </tr>`;
            });
            $('#customerTable tbody').html(rows);
        }
    });
}

function deactivateUser(userId) {
    
    $.ajax({
        url: '/ArtShop/deactivateCustomer.php',
        type: 'POST',
        data: { KID: userId },
        success: function(response) {
            loadCustomers(); // Kundenliste neu laden
        }
    });
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////GUTSCHEINE VERWALTEN///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// Funktion zum Erstellen eines neuen Gutscheincodes
function createVoucher() {
    $.ajax({
        url: '/ArtShop/createVoucher.php', // Pfad zur PHP-Datei, die den Gutschein erstellt
        type: 'POST',
        dataType: 'json',
        data: {
            // Hier können Sie zusätzliche Daten übermitteln, wie Wert und Gültigkeitsdaten
        },
        success: function(response) {
            if (response.success) {
                alert('Gutschein erfolgreich erstellt: ' + response.code);
                loadVouchers(); // Liste der Gutscheine neu laden
            } else {
                alert('Fehler beim Erstellen des Gutscheins: ' + response.error);
            }
        },
        error: function() {
            alert('Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut.');
        }
    });
}

// Funktion zum Laden der Gutscheincodes
function loadVouchers() {
    $.ajax({
        url: '/ArtShop/getVouchers.php', // Pfad zur PHP-Datei, die die Gutscheine liefert
        type: 'GET',
        dataType: 'json',
        success: function(vouchers) {
            var tableRows = vouchers.map(function(voucher) {
                return `<tr>
                            <td>${voucher.Gutscheincode}</td>
                            <td>${voucher.DatumVon}</td>    
                            <td>${voucher.DatumBis}</td>
                            <td>${voucher.Wert}</td>
                            <td>${voucher.Ungueltig ? '1' : '0'}</td>
                        </tr>`;
            }).join('');
            $('#voucherTable tbody').html(tableRows);
        }
    });
}

// Event-Handler für das Erstellen-Button
$('#createVoucherButton').click(function() {
    createVoucher();
});

// Seite wird geladen, Gutscheincodes werden geladen
$(document).ready(function() {
    loadVouchers();
});
