<?php
session_start();


// Zugriffsüberprüfung
if (!isset($_SESSION['admin']) || $_SESSION['admin'] != '1') {
    header('HTTP/1.0 403 Forbidden');
    die('Unauthorized');
}
include("serviceHandler/dbaccess.php");
$KID = $_POST['KID'];

// Ermitteln des aktuellen 'Inaktiv'-Status
$stmt = $db->prepare("SELECT Inaktiv FROM user WHERE KID = ?");
$stmt->bind_param("i", $KID);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row) {
    // Toggle den aktiven Status basierend auf dem aktuellen Wert
    $newStatus = $row['Inaktiv'] ? 0 : 1; // Wenn Inaktiv 1 ist, setze es auf 0 und umgekehrt
    $updateStmt = $db->prepare("UPDATE user SET Inaktiv = ? WHERE KID = ?");
    $updateStmt->bind_param("ii", $newStatus, $KID);
    $updateStmt->execute();

    echo json_encode(['success' => $updateStmt->affected_rows > 0]);
    $updateStmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'User not found']);
}

$stmt->close();
?>