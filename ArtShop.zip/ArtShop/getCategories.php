<?php
include("serviceHandler/dbaccess.php");




// Abfrage vor bereiten und ausführen
$kat_sql = "SELECT * FROM kategorien";
$kat_result = $db->query($kat_sql);
$stmt = $db->prepare($kat_sql);
    $stmt->execute();
    $result = $stmt->get_result();

$categories = [];
if ($kat_result->num_rows > 0) {
    // Kategorien in ein Array lesen
    while ($row = $kat_result->fetch_assoc()) {
        $categories[] = $row;
    }
}

// Kategorien als JSON ausgeben
echo json_encode($categories);



// Datenbankverbindung schließen
$db->close();
?>
