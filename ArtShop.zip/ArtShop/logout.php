<?php
session_start();
session_unset();
session_destroy();

if (isset($_COOKIE['remember_user'])) {
    setcookie('remember_user', '', time() - 3600); // Löscht das Cookie
}

header("Location: /ArtShop/simpleJsonClient/index.html"); // Weiterleitung zur Login-Seite
exit();
?>
