<?php
// Datenbankverbindung
include("serviceHandler/dbaccess.php");

$searchTerm = isset($_GET['term']) ? $_GET['term'] : '';

// Eine einfache SQL-Suche in Ihrer Produkttabelle
// Beachten Sie: Dies ist eine sehr einfache Suchanfrage ohne Optimierung oder Absicherung gegen SQL-Injection
$sql = "SELECT * FROM produkte WHERE Bezeichnung LIKE ?";
$stmt = $db->prepare($sql);
$searchTerm = '%' . $searchTerm . '%';
$stmt->bind_param('s', $searchTerm);
$stmt->execute();
$result = $stmt->get_result();

$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}

echo json_encode($products);
$db->close();
?>
