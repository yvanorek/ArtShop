<?php
session_start(); // Startet oder setzt die aktuelle Session fort


// Prüft, ob der Warenkorb existiert, wenn nicht, erstelle ihn
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Prüfen, ob eine product_id gesendet wurde
if (isset($_POST['product_id'])) {
    $productId = $_POST['product_id'];

    // Prüfen, ob das Produkt bereits im Warenkorb ist
    if (isset($_SESSION['cart'][$productId])) {
        // Erhöht die Menge um 1
        $_SESSION['cart'][$productId]++;
    } else {
        // Fügt das neue Produkt mit der Menge 1 hinzu
        $_SESSION['cart'][$productId] = 1;
    }

    echo "Produkt wurde zum Warenkorb hinzugefügt.";
} else {
    echo "Es wurde keine Produkt-ID gesendet.";
}


// Gibt die aktuelle Anzahl der Produkte im Warenkorb zurück
echo count($_SESSION['cart']);
?>
