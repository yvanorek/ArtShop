
<?php

session_start();
header('Content-Type: application/json');

// Stellen Sie sicher, dass die 'dbaccess.php' Datei keinen Output erzeugt
require_once("serviceHandler/dbaccess.php");



// Prüfen, ob Produkte im Warenkorb gespeichert sind
$cartItems = [];

// Prüfen Sie, ob der Warenkorb in der Session gesetzt ist und geben Sie die Produkte zurück
if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
    // Holen Sie die Produkt-IDs aus der Session
    $ids = array_keys($_SESSION['cart']);
    // Erstellen Sie Platzhalter für die SQL-Abfrage
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    
    // Bereiten Sie das SQL-Statement vor
    $stmt = $db->prepare("SELECT * FROM produkte WHERE PID IN ($placeholders)");

    // Die Produkt-IDs müssen als Array von Parametern übergeben werden
    $stmt->bind_param(str_repeat('i', count($ids)), ...$ids);
    $stmt->execute();
    $result = $stmt->get_result();

    

    // Durchlaufen Sie die Ergebnisse und fügen Sie sie zu $cartItems hinzu
    while ($row = $result->fetch_assoc()) {
        // Fügen Sie die Menge aus der Session hinzu
        $row['Menge'] = $_SESSION['cart'][$row['PID']];
        $cartItems[] = $row;
    }

    $stmt->close();
}

$db->close();

echo json_encode($cartItems);
?>

