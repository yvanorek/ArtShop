<?php
session_start();
include("serviceHandler/dbaccess.php");


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

    $stmt = $db->prepare("SELECT * FROM user WHERE Benutzername = ? OR Mail = ?");
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['Passwort'])) {
        $_SESSION['user_id'] = $user['KID'];
        $_SESSION['admin'] = $user['Admin'];
        // ...
    
        echo json_encode(['success' => true]);
    } else {
        // Anstatt ein `die()` zu verwenden, geben Sie eine Fehlermeldung zurück
        echo json_encode(['success' => false, 'error' => 'Benutzername oder Passwort falsch.']);
    }
    $stmt->close();
}
?>
