<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "artshop";

// Verbindung zur Datenbank
$db = new mysqli($host, $user, $password, $database);

// Prüfen, ob die Verbindung erfolgreich war
if ($db->connect_error) {
    echo "Connection Error: " . $db->connect_error;
    exit();
}

