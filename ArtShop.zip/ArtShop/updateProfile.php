<?php
session_start();
include("serviceHandler/dbaccess.php");

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Benutzer ist nicht eingeloggt.']);
    exit;
}

$user_id = $_SESSION['user_id'];
$anrede = $_POST['anrede'];
$vorname = $_POST['vorname'];
$nachname = $_POST['nachname'];
$adresse = $_POST['adresse'];
$plz = $_POST['plz'];
$ort = $_POST['ort'];
$zahlungsinformation = $_POST['zahlungsinformation'];

// ... sammeln Sie alle anderen Profildaten

$stmt = $db->prepare("UPDATE user SET Anrede = ?, Vorname = ?, Nachname = ? , Adresse = ?, Plz = ?, Ort = ?, Zahlungsinformation = ? WHERE KID = ?");
$stmt->bind_param("sssssssi", $anrede, $vorname, $nachname, $adresse,$plz ,$ort ,$zahlungsinformation , $user_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Datenbankfehler.']);
}

$stmt->close();
?>
