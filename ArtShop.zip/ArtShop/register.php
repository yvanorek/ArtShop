<?php
session_start();
include("serviceHandler/dbaccess.php");

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);

    // Überprüfen, ob der Benutzername oder die E-Mail bereits existiert
    $stmt = $db->prepare("SELECT COUNT(*) FROM user WHERE Benutzername = ? OR Mail = ?");
    $stmt->bind_param("ss", $username, $email);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count > 0) {
        $response['message'] = 'Benutzername oder E-Mail-Adresse existiert bereits.';
        echo json_encode($response);
        exit;
    }

    // Passwortvalidierung wie zuvor
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    if ($password !== $confirm_password) {
        $response['message'] = 'Passwörter stimmen nicht überein!';
        echo json_encode($response);
        exit;
    }

    $password_hashed = password_hash($password, PASSWORD_DEFAULT);

    $anrede = filter_input(INPUT_POST, 'anrede', FILTER_SANITIZE_STRING);
    $vorname = filter_input(INPUT_POST, 'vorname', FILTER_SANITIZE_STRING);
    $nachname = filter_input(INPUT_POST, 'nachname', FILTER_SANITIZE_STRING);
    $adresse = filter_input(INPUT_POST, 'adresse', FILTER_SANITIZE_STRING);
    $plz = filter_input(INPUT_POST, 'plz', FILTER_SANITIZE_STRING);
    $ort = filter_input(INPUT_POST, 'ort', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $benutzername = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $zahlungsinformation = filter_input(INPUT_POST, 'zahlungsinformation', FILTER_SANITIZE_STRING);

    // Einfügen des neuen Benutzers
    $stmt = $db->prepare("INSERT INTO user (Anrede, Vorname, Nachname, Adresse, Plz, Ort, Mail, Benutzername, Passwort, Zahlungsinformation) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssss", $anrede, $vorname, $nachname, $adresse, $plz, $ort, $email, $username, $password_hashed, $zahlungsinformation);
    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = 'Registrierung erfolgreich!';
    } else {
        $response['message'] = 'Fehler beim Einfügen in die Datenbank.';
    }

    $stmt->close();
    $db->close();
    
    echo json_encode($response);
}
?>





