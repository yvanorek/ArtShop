<?php
session_start();
header('Content-Type: application/json');
include("serviceHandler/dbaccess.php");



if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Prüfen, ob der Warenkorb in der Session gesetzt ist
    if (isset($_SESSION['cart'][$product_id])) {
        // Aktualisieren Sie die Menge des Produkts im Warenkorb
        $_SESSION['cart'][$product_id] = $quantity;
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['error' => 'Product not in cart']);
    }
} else {
    echo json_encode(['error' => 'Invalid input']);
}
?>
