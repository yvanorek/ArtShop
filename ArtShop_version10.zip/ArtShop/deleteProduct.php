<?php
// Datenbankverbindung einbinden
include 'serviceHandler/dbaccess.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Überprüfen, ob die Produkt-ID gesetzt ist
    if (isset($_POST['id'])) {
        $productId = $_POST['id'];

        // SQL-Statement zum Löschen des Produkts vorbereiten
        $sql = "DELETE FROM produkte WHERE PID = ?";
        $stmt = $db->prepare($sql);
        $stmt->bind_param("i", $productId);

        if ($stmt->execute()) {
            echo "Produkt erfolgreich gelöscht.";
        } else {
            echo "Fehler beim Löschen des Produkts: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Keine Produkt-ID angegeben.";
    }
}

$db->close();
?>
