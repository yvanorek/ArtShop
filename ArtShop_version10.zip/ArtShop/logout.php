<?php
session_start();
session_unset();
session_destroy();

if (isset($_COOKIE['user_id'])) {
    setcookie("user_id", "", time() - 3600, "/");// Löscht das Cookie
}
/*
if (isset($_COOKIE['remember_user'])) {
    setcookie('remember_user', '', time() - 3600); // Löscht das Cookie
    setcookie("user_id", "", time() - 3600, "/");
}
*/

header("Location: /ArtShop/simpleJsonClient/index.html"); // Weiterleitung zur Login-Seite
exit();
?>
