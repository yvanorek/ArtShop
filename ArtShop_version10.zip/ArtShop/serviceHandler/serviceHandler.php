<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "artshop";

// Verbindung zur Datenbank
$db = new mysqli($host, $user, $password, $database);

// Prüfen, ob die Verbindung erfolgreich war
if ($db->connect_error) {
    echo "Connection Error: " . $db->connect_error;
    exit();
}

include("../businesslogic/simpleLogic.php");

// Abfrage vor bereiten und ausführen
$kat_sql = "SELECT * FROM kategorien";
$kat_result = $db->query($kat_sql);

$categories = [];
if ($kat_result->num_rows > 0) {
    // Kategorien in ein Array lesen
    while ($row = $kat_result->fetch_assoc()) {
        $categories[] = $row;
    }
}

// Kategorien als JSON ausgeben
echo json_encode($categories);



// Datenbankverbindung schließen
$db->close();
?>
