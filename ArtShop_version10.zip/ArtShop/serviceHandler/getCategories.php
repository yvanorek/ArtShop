<?php

include("dbaccess.php");
include("../businesslogic/simpleLogic.php");

// Abfrage vor bereiten und ausführen
$kat_sql = "SELECT * FROM kategorien";
$kat_result = $db->query($kat_sql);

$categories = [];
if ($kat_result->num_rows > 0) {
    // Kategorien in ein Array lesen
    while ($row = $kat_result->fetch_assoc()) {
        $categories[] = $row;
    }
}

// Kategorien als JSON ausgeben
echo json_encode($categories);