<?php
include("dbaccess.php");
include("../businesslogic/simpleLogic.php");

$pro_sql = "SELECT * FROM produkte";
$pro_result = $db->query($pro_sql);

$products = [];
if ($pro_result->num_rows > 0) {
    // Produkte in ein Array lesen
    while ($row = $pro_result->fetch_assoc()) {
        $products[] = $row;
    }
}

// Produkte als JSON ausgeben
echo json_encode($products);


// Datenbankverbindung schließen
$db->close();