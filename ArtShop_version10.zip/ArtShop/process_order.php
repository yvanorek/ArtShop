<?php
session_start();

include 'serviceHandler/dbaccess.php'; // 确保文件路径正确

// 函数来处理和记录错误
function handleError($error_message) {
    echo json_encode(array("error" => $error_message));
    error_log("Fehler: " . $error_message); // 记录错误到服务器日志
    exit();
}

// 启用错误报告
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$response = array();

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check if user is logged in
        if (!isset($_SESSION['user_id'])) {
            handleError('Bitte melden Sie sich an, um die Bestellung abzuschließen.');
        }

        // Check if cart is not empty
        if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
            handleError('Ihr Warenkorb ist leer.');
        }

        $user_id = $_SESSION['user_id'];
        $paymentMethod = $_POST['payment_method'];
        $totalAmount = $_POST['total_amount'];
        $voucherCode = isset($_POST['voucher_code']) ? $_POST['voucher_code'] : null;

        // Validate payment method
        if (empty($paymentMethod)) {
            handleError('Bitte wählen Sie eine Zahlungsmethode aus.');
        }

        $discount = 0;

        if ($paymentMethod == 'Gutschein' && !empty($voucherCode)) {
            // 验证并应用优惠券
            $sql = "SELECT Wert, Ungültig FROM gutscheine WHERE Gutscheincode = ? AND DatumBis >= CURDATE()";
            $stmt = $db->prepare($sql);
            if (!$stmt) {
                handleError("Fehler bei der Vorbereitung der SQL-Anweisung: " . $db->error);
            }
            $stmt->bind_param("s", $voucherCode);
            if (!$stmt->execute()) {
                handleError("Fehler bei der Ausführung der SQL-Anweisung: " . $stmt->error);
            }
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                if ($row['Ungültig']) {
                    handleError("Dieser Gutschein wurde bereits eingelöst.");
                } else {
                    $discount = $row['Wert'];
                    $newTotalAmount = $totalAmount - $discount;

                    if ($newTotalAmount < 0) {
                        // 部分使用优惠券，更新优惠券余额
                        $remainingValue = $discount - $totalAmount;
                        $newTotalAmount = 0;

                        $updateVoucherSql = "UPDATE gutscheine SET Wert = ?, Ungültig = 0 WHERE Gutscheincode = ?";
                        $updateStmt = $db->prepare($updateVoucherSql);
                        if (!$updateStmt) {
                            handleError("Fehler bei der Vorbereitung der SQL-Anweisung für Update: " . $db->error);
                        }
                        $updateStmt->bind_param("ds", $remainingValue, $voucherCode);
                    } else {
                        // 完全使用优惠券，标记为已兑换
                        $updateVoucherSql = "UPDATE gutscheine SET Ungültig = 1 WHERE Gutscheincode = ?";
                        $updateStmt = $db->prepare($updateVoucherSql);
                        if (!$updateStmt) {
                            handleError("Fehler bei der Vorbereitung der SQL-Anweisung für Update: " . $db->error);
                        }
                        $updateStmt->bind_param("s", $voucherCode);
                    }
                    if (!$updateStmt->execute()) {
                        handleError("Fehler bei der Ausführung der SQL-Anweisung für Update: " . $updateStmt->error);
                    }
                    $updateStmt->close();
                }
            } else {
                handleError("Ungültiger oder abgelaufener Gutscheincode.");
            }
            $stmt->close();
        } else {
            $newTotalAmount = $totalAmount;
        }

        // 如果新总金额大于0，且支付方式不是优惠券，用户需要支付剩余金额
        //if ($newTotalAmount > 0 && $paymentMethod == 'Gutschein') {
          //  handleError("Der Gutschein deckt nicht den gesamten Betrag ab. Bitte wählen Sie eine andere Zahlungsmethode, um den verbleibenden Betrag zu begleichen.");
        //}

        // 根据支付方式处理订单逻辑
        if ($paymentMethod == 'Kreditkarte') {
            // 处理信用卡支付逻辑
            // 这里可以添加具体的信用卡支付处理代码，例如调用支付网关API等
        } else if ($paymentMethod == 'Paypal') {
            // 处理 PayPal 支付逻辑
            // 这里可以添加具体的 PayPal 支付处理代码，例如调用 PayPal API 等
        }

        // 插入订单数据到 bestellungen 表
        $order_id = storeOrderInDB($user_id, $_SESSION['cart'], $newTotalAmount, $paymentMethod);
        
        // 清空购物车
        unset($_SESSION['cart']);

        $response['status'] = 'success';
        $response['order_id'] = $order_id;
        $response['amount'] = $newTotalAmount;
        $response['message'] = "Bestellung erfolgreich abgeschlossen. Zu zahlender Betrag: " . $newTotalAmount . " Euro.";
    }
} catch (Exception $e) {
    handleError("Ein unerwarteter Fehler ist aufgetreten: " . $e->getMessage());
}

$db->close();

echo json_encode($response);

// Function to calculate total amount
function calculateTotalAmount($cart) {
    $total = 0;
    foreach ($cart as $product_id => $quantity) {
        $product = getProductDetails($product_id);
        $total += $product['price'] * $quantity;
    }
    return $total;
}

// Function to get product details
function getProductDetails($product_id) {
    global $db; // Use the global database connection defined in dbaccess.php

    $stmt = $db->prepare("SELECT Bezeichnung, Preis FROM produkte WHERE PID = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $stmt->bind_result($name, $price);
    $stmt->fetch();
    $stmt->close();

    return [
        'name' => $name,
        'price' => $price
    ];
}

// Function to store order in the database
function storeOrderInDB($user_id, $cart, $total_amount, $payment_method) {
    global $db; // Use the global database connection defined in dbaccess.php

    // Start transaction
    $db->begin_transaction();

    try {
        // Insert order into bestellungen table
        $stmt = $db->prepare("INSERT INTO bestellungen (KID, Gesamtsumme, Zahlungsinformation) VALUES (?, ?, ?)");
        $stmt->bind_param("ids", $user_id, $total_amount, $payment_method);
        $stmt->execute();
        $order_id = $stmt->insert_id;
        $stmt->close();

        // Insert order items into bestellposition table
        foreach ($cart as $product_id => $quantity) {
            $product = getProductDetails($product_id);
            $stmt = $db->prepare("INSERT INTO bestellposition (BID, PID, Menge, Preis) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiid", $order_id, $product_id, $quantity, $product['price']);
            $stmt->execute();
            $stmt->close();
        }

        // Commit transaction
        $db->commit();

        return $order_id;
    } catch (Exception $e) {
        // Rollback transaction on error
        $db->rollback();
        throw $e;
    }
}
?>
