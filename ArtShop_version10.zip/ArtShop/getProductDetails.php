<?php
// Datenbankverbindung einbinden
include 'serviceHandler/dbaccess.php';

// Header für JSON-Ausgabe
header('Content-Type: application/json');

// Überprüfen, ob die Produkt-ID gesetzt ist
if (isset($_GET['id'])) {
    $productId = $_GET['id'];

    // SQL-Statement zum Abrufen der Produktdetails vorbereiten
    $sql = "SELECT * FROM produkte WHERE PID = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("i", $productId);
    $stmt->execute();

    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
        echo json_encode($product);
    } else {
        echo json_encode(['error' => 'Produkt nicht gefunden']);
    }

    $stmt->close();
} else {
    echo json_encode(['error' => 'Keine Produkt-ID angegeben']);
}

$db->close();
?>
