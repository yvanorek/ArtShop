<?php
include("serviceHandler/dbaccess.php");

$searchTerm = isset($_GET['term']) ? $_GET['term'] : '';
file_put_contents('debug.log', "Search term: $searchTerm\n", FILE_APPEND);

$sql = "SELECT * FROM produkte WHERE Bezeichnung LIKE ?";
$stmt = $db->prepare($sql);
$searchTerm = '%' . $searchTerm . '%';
$stmt->bind_param('s', $searchTerm);

if (!$stmt->execute()) {
    file_put_contents('debug.log', "SQL error: " . $stmt->error . "\n", FILE_APPEND);
}

$result = $stmt->get_result();

$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}

echo json_encode($products);
$db->close();
?>
