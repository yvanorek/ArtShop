<?php
include("serviceHandler/dbaccess.php");

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['BID']) || !isset($_POST['PID'])) {
        echo json_encode(['error' => 'Ungültige Anfrage.']);
        exit;
    }

    $BID = $_POST['BID'];
    $PID = $_POST['PID'];

    // Holen Sie sich den Preis und die Menge des Produkts, das entfernt wird
    $priceSql = "SELECT Preis, Menge FROM bestellposition WHERE BID = ? AND PID = ?";
    $priceStmt = $db->prepare($priceSql);
    $priceStmt->bind_param("ii", $BID, $PID);
    $priceStmt->execute();
    $priceResult = $priceStmt->get_result();
    if ($priceResult->num_rows > 0) {
        $product = $priceResult->fetch_assoc();
        $productPrice = $product['Preis'] * $product['Menge'];
    } else {
        echo json_encode(['error' => 'Produkt nicht gefunden.']);
        exit;
    }
    $priceStmt->close();

    // Löschen Sie die Bestellposition
    $deleteSql = "DELETE FROM bestellposition WHERE BID = ? AND PID = ?";
    $deleteStmt = $db->prepare($deleteSql);
    if (!$deleteStmt) {
        echo json_encode(['error' => 'Fehler bei der Vorbereitung der Abfrage: ' . $db->error]);
        exit;
    }
    $deleteStmt->bind_param("ii", $BID, $PID);
    $deleteStmt->execute();

    if ($deleteStmt->affected_rows > 0) {
        // Aktualisieren Sie den Gesamtpreis der Bestellung
        $updateSql = "UPDATE bestellungen SET Gesamtsumme = Gesamtsumme - ? WHERE BID = ?";
        $updateStmt = $db->prepare($updateSql);
        $updateStmt->bind_param("di", $productPrice, $BID);
        $updateStmt->execute();
        $updateStmt->close();

        echo json_encode(['success' => 'Produkt erfolgreich aus der Bestellung entfernt.']);
    } else {
        echo json_encode(['error' => 'Fehler beim Entfernen des Produkts aus der Bestellung.']);
    }

    $deleteStmt->close();
} else {
    echo json_encode(['error' => 'Ungültige Anfrage.']);
}

$db->close();
?>
