<?php
session_start();
header('Content-Type: application/json');

require_once("serviceHandler/dbaccess.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $voucherCode = filter_input(INPUT_POST, 'voucher_code', FILTER_SANITIZE_STRING);
    error_log("Received voucher code: " . $voucherCode); // Debugging line

    if ($voucherCode) {
        // Check if the voucher code is valid and not expired
        $stmt = $db->prepare("SELECT GID, Wert, Ungültig FROM gutscheine WHERE Gutscheincode = ? AND Ungültig = 0");
        $stmt->bind_param("s", $voucherCode);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $voucher = $result->fetch_assoc();
            $voucherValue = $voucher['Wert'];
            error_log("Voucher value from database: " . $voucherValue); // Debugging line

            // Check if cart total is set in session
            if (isset($_SESSION['cart_total'])) {
                $cartTotal = $_SESSION['cart_total'];
                error_log("Cart total from session: " . $cartTotal); // Debugging line

                // Calculate the discount
                $discount = min($voucherValue, $cartTotal); // Use the lesser of the voucher value or the cart total
                $newTotal = $cartTotal - $discount;
                
                error_log("Calculated discount: " . $discount); // Debugging line
                error_log("New cart total after applying voucher: " . $newTotal); // Debugging line

                echo json_encode(['success' => true, 'discount' => $discount, 'newTotal' => $newTotal]);
            } else {
                error_log("Cart total is not set in session"); // Debugging line
                echo json_encode(['success' => false, 'message' => 'Warenkorb Gesamtbetrag ist nicht gesetzt.']);
            }
        } else {
            error_log("Invalid or expired voucher code"); // Debugging line
            echo json_encode(['success' => false, 'message' => 'Ungültiger oder abgelaufener Gutscheincode.']);
        }

        $stmt->close();
    } else {
        error_log("No voucher code entered"); // Debugging line
        echo json_encode(['success' => false, 'message' => 'Kein Gutscheincode eingegeben.']);
    }
} else {
    error_log("Invalid request method"); // Debugging line
    echo json_encode(['success' => false, 'message' => 'Ungültige Anfrage.']);
}

$db->close();
?>
