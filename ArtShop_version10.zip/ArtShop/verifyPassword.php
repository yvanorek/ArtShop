<?php
session_start();
include("serviceHandler/dbaccess.php"); // Pfad zur Datei, die die Datenbankverbindung handhabt

$response = ['success' => false];

if (isset($_POST['password'])) {
    $password = $_POST['password'];
    $userId = $_SESSION['user_id']; // Angenommen, die Benutzer-ID wird in der Session gespeichert

  

    // Passwort-Hash aus der Datenbank abrufen
    $query = "SELECT Passwort FROM user WHERE KID = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($Passwort);
    $stmt->fetch();
    $stmt->close();

    // Passwort überprüfen
    if (password_verify($password, $Passwort)) {
        $response['success'] = true;
    } else {
        $response['error'] = 'Falsches Passwort';
    }
} else {
    $response['error'] = 'Passwort nicht angegeben';
}

// JSON-Antwort zurückgeben
echo json_encode($response);
?>
