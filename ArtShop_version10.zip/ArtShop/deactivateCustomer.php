<?php
include("serviceHandler/dbaccess.php");

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['KID'])) {
        echo json_encode(['error' => 'Ungültige Anfrage.']);
        exit;
    }

    $KID = $_POST['KID'];

    // Überprüfen Sie den aktuellen Status des Kunden
    $statusSql = "SELECT Inaktiv FROM user WHERE KID = ?";
    $statusStmt = $db->prepare($statusSql);
    $statusStmt->bind_param("i", $KID);
    $statusStmt->execute();
    $statusResult = $statusStmt->get_result();
    $currentStatus = $statusResult->fetch_assoc()['Inaktiv'];
    $statusStmt->close();

    // Invertieren Sie den aktuellen Status
    $newStatus = $currentStatus == 1 ? 0 : 1;

    // Aktualisieren Sie den Status des user
    $updateSql = "UPDATE user SET Inaktiv = ? WHERE KID = ?";
    $updateStmt = $db->prepare($updateSql);
    $updateStmt->bind_param("ii", $newStatus, $KID);
    $updateStmt->execute();

    if ($updateStmt->affected_rows > 0) {
        echo json_encode(['success' => 'Kundenstatus erfolgreich geändert.']);
    } else {
        echo json_encode(['error' => 'Fehler beim Ändern des Kundenstatus.']);
    }

    $updateStmt->close();
} else {
    echo json_encode(['error' => 'Ungültige Anfrage.']);
}

$db->close();
?>
