<?php
session_start();

$response = ['sessionExpired' => false];

// Überprüfen, ob der Benutzer "Login merken" aktiviert hat und ob ein Cookie vorhanden ist
if (isset($_SESSION['remember']) && $_SESSION['remember']= true && isset($_COOKIE['user_id'])) {
    // Erneuern der Session, ohne sie zu zerstören, da "Login merken" aktiviert ist
    $_SESSION['last_activity'] = time();
} else {
    // Prüfen auf Inaktivität nur, wenn "Login merken" nicht aktiviert ist
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 300)) {
        // Session löschen, wenn Inaktivität mehr als 5 Minuten beträgt
        $_SESSION = array();
        session_destroy();
        $response['sessionExpired'] = true;
    } else {
        // Aktualisieren der letzten Aktivität
        $_SESSION['last_activity'] = time();
    }
}

echo json_encode($response);
