<?php
// Datenbankverbindung
include 'serviceHandler/dbaccess.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productName = $_POST['productName'];
    $productDescription = $_POST['productDescription'];
    $productPrice = $_POST['productPrice'];
    $productCategory = $_POST['productCategory'];

    $targetDir = "productbilder/"; // Relativer Pfad von htdocs
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true); // Verzeichnis erstellen, falls es nicht existiert
    }
    $targetFile = $targetDir . basename($_FILES["productImage"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Bild überprüfen
    $check = getimagesize($_FILES["productImage"]["tmp_name"]);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        echo "Datei ist kein Bild.";
        $uploadOk = 0;
    }

    // Bild hochladen
    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["productImage"]["tmp_name"], $targetFile)) {
            echo "Das Bild ". htmlspecialchars(basename($_FILES["productImage"]["name"])). " wurde hochgeladen.";

            // Relativen Pfad des Bildes erstellen für die Datenbank
            $relativePath = "/ArtShop/" . $targetFile; // Hier wird /ArtShop/ hinzugefügt

            // Produkt in die Datenbank einfügen
            $sql = "INSERT INTO produkte (Bezeichnung, Beschreibung, Preis, KatID, Bildpfad) VALUES (?, ?, ?, ?, ?)";
            $stmt = $db->prepare($sql); // Verwende $db von dbaccess.php
            $stmt->bind_param("ssdss", $productName, $productDescription, $productPrice, $productCategory, $relativePath);

            if ($stmt->execute()) {
                echo "Neues Produkt wurde erfolgreich hinzugefügt.";
            } else {
                echo "Fehler: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "Entschuldigung, es gab einen Fehler beim Hochladen Ihres Bildes.";
        }
    }

    $db->close(); // Verwende $db von dbaccess.php
}
?>
