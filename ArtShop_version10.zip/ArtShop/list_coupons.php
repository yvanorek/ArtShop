<?php
include ("serviceHandler/dbaccess.php");

header('Content-Type: application/json');

$currentDate = date('Y-m-d');

$sql = "SELECT GID, Gutscheincode, Wert, DatumBis, Ungültig, DatumVon FROM gutscheine ORDER BY DatumVon DESC";
$result = $db->query($sql);

$coupons = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Check if the coupon is expired
        if ($row['DatumBis'] < $currentDate) {
            // Update the 'Ungültig' field in the database
            $updateSql = "UPDATE gutscheine SET Ungültig = 1 WHERE GID = ?";
            $updateStmt = $db->prepare($updateSql);
            $updateStmt->bind_param("i", $row['GID']);
            $updateStmt->execute();
            $updateStmt->close();
            $row['Ungültig'] = 1;
        }
        $coupons[] = $row;
    }
    echo json_encode($coupons);
} else {
    echo json_encode([]);
}
$db->close();
?>
