$(document).ready(function() {
    loadCategories();

    $('#productForm').submit(function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        var productId = $('#productId').val();
        console.log("Product ID: " + productId);
        var url = productId ? '/ArtShop/updateProduct.php' : '/ArtShop/createProduct.php'; // Hier war der Fehler

        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                resetForm();
                alert('Produkt gespeichert!');
                location.reload(); // Seite neu laden
            },
            error: function() {
                alert('Fehler beim Speichern des Produkts.');
            }
        });
    });
});

function loadCategories() {
    $.ajax({
        url: '/ArtShop/getCategories.php', // Pfad zum PHP-Skript, das die Kategorien zurückgibt
        type: 'GET',
        dataType: 'json',
        success: function(categories) {
            console.log("Kategorien geladen");
            loadProductsFromAllCategories(categories);
        }
    });
}

function loadProductsFromAllCategories(categories) {
    let allProducts = [];

    categories.forEach(category => {
        $.ajax({
            url: '/ArtShop/getProducts.php',
            type: 'GET',
            data: { category_id: category.KatID },
            dataType: 'json',
            async: false, // Warten, bis die Anfrage abgeschlossen ist
            success: function(products) {
                allProducts = allProducts.concat(products);
            }
        });
    });

    displayProducts(allProducts);
}

function displayProducts(products) {
    var rows = '';
    $('#productTable tbody').empty();

    products.forEach(function(product) {
        rows += '<tr>' +
                '<td>' + product.Bezeichnung + '</td>' +
                '<td>' + product.Beschreibung + '</td>' +
                '<td>' + product.Bewertung + '</td>' +
                '<td>' + product.Preis + '</td>' +
                '<td><img src="' + product.Bildpfad + '" width="100px"></td>' +
                '<td>' +
                    '<button onclick="editProduct(' + product.PID + ')">Bearbeiten</button>' +
                    '<button onclick="deleteProduct(' + product.PID + ')">Löschen</button>' +
                '</td>' +
                '</tr>';
    });
    $('#productTable tbody').append(rows);
}

function deleteProduct(id) {
    if (confirm('Sind Sie sicher, dass Sie dieses Produkt löschen möchten?')) {
        $.ajax({
            url: '/ArtShop/deleteProduct.php',
            type: 'POST',
            data: { id: id },
            success: function(response) {
                alert(response);
                location.reload(); // Seite neu laden
            },
            error: function() {
                alert('Fehler beim Löschen des Produkts.');
            }
        });
    }
}

function resetForm() {
    $('#productForm')[0].reset();
    $('#productId').val('');
}

function editProduct(productId) {
    // AJAX-Anfrage, um Produktdetails basierend auf productId zu laden
    $.ajax({
        url: '/ArtShop/getProductDetails.php',
        type: 'GET',
        data: { id: productId },
        dataType: 'json',
        success: function(product) {
            if (product.error) {
                alert(product.error);
            } else {
                // Befülle das Formular mit den Produktdetails
                $('#productId').val(product.PID);
                $('#productName').val(product.Bezeichnung);
                $('#productDescription').val(product.Beschreibung);
                $('#productPrice').val(product.Preis);
                $('#productCategory').val(product.KatID);
                $('#existingImage').val(product.Bildpfad); // Setze den Pfad des bestehenden Bildes
            }
        }
    });
}
