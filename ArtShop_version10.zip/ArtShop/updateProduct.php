<?php
// Datenbankverbindung einbinden
include 'serviceHandler/dbaccess.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Produktinformationen aus dem Formular
    $productId = $_POST['productId'];
    $productName = $_POST['productName'];
    $productDescription = $_POST['productDescription'];
    $productPrice = $_POST['productPrice'];
    $productCategory = $_POST['productCategory'];

    // Überprüfen, ob ein neues Bild hochgeladen wurde
    if (!empty($_FILES['productImage']['name'])) {
        $targetDir = "productbilder/"; // Relativer Pfad von htdocs
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true); // Verzeichnis erstellen, falls es nicht existiert
        }
        $targetFile = $targetDir . basename($_FILES["productImage"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Bild überprüfen
        $check = getimagesize($_FILES["productImage"]["tmp_name"]);
        if ($check !== false) {
            $uploadOk = 1;
        } else {
            echo "Datei ist kein Bild.";
            $uploadOk = 0;
        }

        // Bild hochladen
        if ($uploadOk == 1) {
            if (move_uploaded_file($_FILES["productImage"]["tmp_name"], $targetFile)) {
                echo "Das Bild ". htmlspecialchars(basename($_FILES["productImage"]["name"])). " wurde hochgeladen.";
                // Relativen Pfad des Bildes erstellen für die Datenbank
                $relativePath = "/ArtShop/" . $targetFile;
            } else {
                echo "Entschuldigung, es gab einen Fehler beim Hochladen Ihres Bildes.";
            }
        }
    } else {
        // Kein neues Bild hochgeladen, alten Pfad beibehalten
        $relativePath = $_POST['existingImage'];
    }

    // Produktinformationen in die Datenbank aktualisieren
    $sql = "UPDATE produkte SET Bezeichnung = ?, Beschreibung = ?, Preis = ?, KatID = ?, Bildpfad = ? WHERE PID = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("ssdssi", $productName, $productDescription, $productPrice, $productCategory, $relativePath, $productId);

    if ($stmt->execute()) {
        echo "Produkt erfolgreich aktualisiert.";
    } else {
        echo "Fehler beim Aktualisieren des Produkts: " . $stmt->error;
    }

    $stmt->close();
}

$db->close();
?>
