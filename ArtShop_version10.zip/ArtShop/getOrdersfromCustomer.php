<?php
session_start();
include("serviceHandler/dbaccess.php");

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Bitte melden Sie sich an, um die Bestellungen einzusehen.']);
    exit;
}

// Check if KID parameter is set
if (!isset($_GET['KID'])) {
    echo json_encode(['error' => 'Keine Kunden-ID angegeben.']);
    exit;
}

$kid = $_GET['KID'];

// Prepare and execute the SQL statement
$sql = "SELECT BID, Gesamtsumme, Zahlungsinformation, Bestelldatum FROM bestellungen WHERE KID = ? ORDER BY Bestelldatum DESC";
$stmt = $db->prepare($sql);
if (!$stmt) {
    echo json_encode(['error' => 'Fehler bei der Vorbereitung der Abfrage: ' . $db->error]);
    exit;
}
$stmt->bind_param("i", $kid);
$stmt->execute();
$result = $stmt->get_result();

$orders = [];
while ($row = $result->fetch_assoc()) {
    $row['Gesamtsumme'] = round($row['Gesamtsumme'], 2);
    $orders[] = $row;
}

$stmt->close();
echo json_encode($orders);
?>
