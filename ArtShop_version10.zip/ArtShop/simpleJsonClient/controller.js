


$(document).ready(function () {
  // Der Code innerhalb dieser Funktion wird ausgeführt, wenn das Dokument vollständig geladen ist.

  // Navbar wird geladen
  $("#navbar-placeholder").load(
    "/ArtShop/simpleJsonClient/config/navbar.php",
    function () {
      setTimeout(() => {
        // Nachdem die Navbar geladen wurde, binden wir einen Event-Handler an den Suchfeld-Eingabewert
      // Wenn der Benutzer in das Suchfeld eingibt, wird diese Funktion ausgeführt
        $("#product-search").on("input", function () {
          var searchTerm = $('#product-search').val(); // Holt den aktuellen Wert des Suchfeldes
          searchProducts(searchTerm); // Funktion zum Suchen der Produkte wird aufgerufen
        });
      }, 100);
      
    }
  );

  // Laden weiterer Inhalte
  updateCartItems(); // Aktualisiert die Artikel im Warenkorb
  updateCartCount(); // Aktualisiert die Anzahl der Artikel im Warenkorb
  loadCategories(); // Lädt die Kategorien, wenn die Seite vollständig geladen ist

});

$(document).on("click", "#cartlink", function (e) {
  e.preventDefault(); // Verhindert die Standardaktion des Klickereignisses
  window.location.href = this.href; // Ändert die URL im Browser zur URL des Warenkorbs
  updateCartItems(); // Aktualisiert die Artikel im Warenkorb
  //window.location.href = this.href;
  // Der Kommentar oben deutet darauf hin, dass es eine Alternative gab, bei der nur die URL geändert wurde, ohne vorher die Artikel zu aktualisieren.
});


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//DISPLAY WEBSHOP///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function loadCategories() {
  $.ajax({
    url: "/ArtShop/getCategories.php", // URL für die AJAX-Anfrage, die die Kategorien abruft
    type: "GET", // HTTP-Methode ist GET
    dataType: "json", // Erwartetes Datenformat ist JSON
    success: function (categories) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      console.log(categories); // Ausgabe der gesamten Kategorien zur Konsole
      categories.forEach(function (category) { // Schleife durch jede Kategorie
        console.log(category); // Ausgabe der aktuellen Kategorie zur Konsole
        $("#categories").append( // Hinzufügen eines neuen Buttons zur Kategorie-Container
          $("<button></button>") // Erstellen eines neuen Button-Elements
            .addClass("category-btn") // Hinzufügen der CSS-Klasse 'category-btn' zum Button
            .text(category.Bezeichnung) // Setzen des Textes des Buttons zur Bezeichnung der Kategorie
            .click(function () { // Hinzufügen eines Klick-Event-Handlers zum Button
              loadProducts(category.KatID); // Laden der Produkte für die ausgewählte Kategorie
              console.log(category.KatID); // Ausgabe der Kategorie-ID zur Konsole
            })
        );
        $("#categories .category-btn:first").click(); // Klickt automatisch auf den ersten Button, um Produkte dieser Kategorie zu laden
      });
    },
  });
}


function loadProducts(categoryId) {
  $.ajax({
    url: "../getProducts.php", // URL für die AJAX-Anfrage, die die Produkte abruft
    type: "GET", // HTTP-Methode ist GET
    data: { category_id: categoryId }, // Daten, die an den Server gesendet werden (die Kategorie-ID)
    dataType: "json", // Erwartetes Datenformat ist JSON
    success: function (products) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      displayProducts(products); // Nutzt die gemeinsame Funktion zum Anzeigen der Produkte
    },
  });
}


function displayProducts(products) {
  console.log("inProducts"); // Ausgabe zur Konsole, um den Einstieg in die Funktion zu bestätigen
  console.log(products); // Ausgabe der Liste der Produkte zur Konsole
  $("#products").empty(); // Löscht vorherige Produkte, bevor neue geladen werden
  products.forEach(function (product) { // Schleife durch jedes Produkt
    console.log(product); // Ausgabe des aktuellen Produkts zur Konsole
    // Erstellen eines neuen Div-Elements für das Produkt mit HTML-Inhalt
    var productDiv = $('<div class="product"></div>').html(
      '<img src="' + product.Bildpfad + '" alt="' + product.Name + '">' + // Produktbild mit Pfad und Alternativtext
      "<h4>" + product.Bezeichnung + "</h4>" + // Produktbezeichnung
      "<span>" + product.Preis.toFixed(2).replace(".", ",") + " Euro</span>" // Produktpreis, formatiert als Dezimalzahl mit Komma
    );
    // Erstellen eines neuen Buttons für "In den Warenkorb"
    var cartButton = $("<button>In den Warenkorb</button>").click(function () {
      addToCart(product.PID); // Funktion zum Hinzufügen des Produkts in den Warenkorb, identifiziert durch PID
    });
    productDiv.append(cartButton); // Fügt den Button zum Produkt-Div hinzu
    $("#products").append(productDiv); // Fügt das gesamte Produkt-Div zum Produkten-Container hinzu
  });
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//PRODUKTSUCHE///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function searchProducts(searchTerm) {

  $.ajax({
    url: "/ArtShop/searchProducts.php", // Path to the search script
    type: "GET",
    data: { term: searchTerm },
    dataType: "json",
    success: function (products) {
      // Update the product view with search results
      console.log("Search results: ", products);
      displayProducts(products);
    },
    error: function (xhr, status, error) {
      // Error handling if the AJAX request fails
      console.error("Search error: ", status, error);
    },
  });
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//REGISTRIERUNG///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// ist in registrierung.html
/*document.addEventListener("DOMContentLoaded", function () {
  // Der Code innerhalb dieser Funktion wird ausgeführt, wenn das Dokument vollständig geladen ist.
  var registrationForm = document.getElementById("registrationForm"); // Holt das Registrierungsformular-Element
  registrationForm.addEventListener("submit", function (e) {
    e.preventDefault(); // Verhindert das Standardverhalten des Formulars (Seiten-Neuladung)
    var formData = new FormData(registrationForm); // Holt alle Formulardaten
    var password = formData.get("password"); // Holt das Passwort aus den Formulardaten
    var confirm_password = document.getElementById("confirm_password").value; // Holt das Bestätigungspasswort aus dem Formular

    if (password !== confirm_password) { // Überprüft, ob die Passwörter übereinstimmen
      alert("Passwörter stimmen nicht überein!"); // Zeigt eine Warnung, wenn die Passwörter nicht übereinstimmen
      return; // Beendet die Funktion, um die Registrierung zu verhindern
    }

    fetch("/ArtShop/register.php", { // Sendet eine POST-Anfrage an die Registrierungs-URL
      method: "POST", // HTTP-Methode ist POST
      body: formData, // Die Formulardaten werden als Body der Anfrage gesendet
    })
      .then((response) => response.json()) // Wandelt die Antwort in JSON um
      .then((data) => {
        if (data.success) { // Überprüft, ob die Registrierung erfolgreich war
          alert("Registrierung erfolgreich!"); // Zeigt eine Erfolgsmeldung
        } else {
          alert("Fehler: " + data.message); // Zeigt eine Fehlermeldung, wenn die Registrierung fehlschlägt
        }
      })
      .catch((error) => {
        console.error("Fehler: ", error); // Loggt technische Fehler in die Konsole
        alert(
          "Ein technischer Fehler ist aufgetreten. Bitte versuchen Sie es später noch einmal."
        ); // Zeigt eine allgemeine Fehlermeldung
      });
  });
});*/


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//LOGIN///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

document.addEventListener("DOMContentLoaded", function () {
  // Bindet das Formular-Submit-Event an die AJAX-Funktion
  var loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.onsubmit = function (e) {
      e.preventDefault(); // Stoppt die normale Formularübermittlung
      var formData = new FormData(this); // Holt alle Formulardaten

      // Führt die AJAX-Anfrage aus
      fetch("/ArtShop/login.php", {
        method: "POST", // HTTP-Methode ist POST
        body: formData, // Die Formulardaten werden als Body der Anfrage gesendet
      })
        .then((response) => response.json()) // Wandelt die Antwort in JSON um
        .then((data) => {
          if (data.success) {
            // Verarbeitet die erfolgreiche Anmeldung
            console.log("Erfolgreich eingeloggt");

             window.location.href = "/ArtShop/simpleJsonClient/index.html"; // Leitet den Benutzer zur Startseite weiter
            
          } else {
            // Fehlermeldung anzeigen
            alert("Login fehlgeschlagen: " + data.error); // Zeigt eine Fehlermeldung an
          }
        })
        .catch((error) => {
          console.error("Fehler bei der Anfrage: ", error); // Loggt technische Fehler in die Konsole
          alert(
            "Ein Fehler ist aufgetreten. Bitte versuchen Sie es später noch einmal."
          ); // Zeigt eine allgemeine Fehlermeldung
        });
    };
  }
});


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//LOGIN MERKEN BZW SESSION DESTROYEN///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
document.addEventListener('DOMContentLoaded', function() {
    // Startet ein Intervall, das alle 5 Minuten (300000 Millisekunden) die Session prüft
    setInterval(checkSessionActivity, 300000); // Zeitintervall 
});*/

function checkSessionActivity() {
  console.log("check session1");
  $.ajax({
    url: "/ArtShop/initialize.php",
    method: "GET",
    success: function (response) {
      console.log("check session2");
      if ((response.sessionExpired = true)) {
        logoutUser();
        console.log("check session3");
        alert(
          "Ihre Session ist abgelaufen. Sie werden zur Login-Seite weitergeleitet."
        );
        window.location.href = "/ArtShop/simpleJsonClient/config/login.html"; // Weiterleitung zur Login-SeiteC: simpleJsonClient\config\login.html
      } else {
        console.log("check session4");
      }
    },
    error: function (xhr, status, error) {
      console.log("check session5");
      console.error("Fehler beim Überprüfen der Session: ", error);
    },
  });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//LOGOUT///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function logoutUser() {
  console.log("check session1--------1"); // Debugging-Ausgabe zur Konsole
  $.ajax({
    url: "/ArtShop/logout.php", // Der Pfad zum PHP-Skript, das die Abmeldung durchführt
    method: "GET", // HTTP-Methode ist GET
    success: function (response) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      console.log("check session2--------1"); // Debugging-Ausgabe zur Konsole
      // Optional: Weiterleiten zur Login-Seite oder Aktualisieren der Seite
      window.location.href = "/ArtShop/login.html"; // Leitet zur Login-Seite weiter 
    },
    error: function (xhr, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      console.log("check session5--------1"); // Debugging-Ausgabe zur Konsole
      console.error("Fehler beim Überprüfen der Session: ", error); // Loggt den Fehler zur Konsole
    },
  });
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//MEIN KONTO///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// in meinKonto.html eingefügt
/*
$(document).ready(function () {
  // Profilinformationen laden
  loadProfile();

  // Event-Listener für das Absenden des Profilformulars
  $("#profileForm").on("submit", function (e) {
    e.preventDefault(); // Verhindert das Standardverhalten des Formulars (Seiten-Neuladung)
    $("#passwordModal").modal("show"); // Zeigt das Passwort-Modal an
  });

  // Event-Listener für das Absenden des Passwortformulars
  $("#passwordForm").on("submit", function (e) {
    e.preventDefault(); // Verhindert das Standardverhalten des Formulars (Seiten-Neuladung)
    verifyPassword(); // Ruft die Funktion zur Passwortverifizierung auf
  });
});

// Funktion zum Laden der Profilinformationen
function loadProfile() {
  $.ajax({
    url: "/ArtShop/getProfile.php", // Der Pfad zum PHP-Skript, das die Profilinformationen lädt
    type: "GET", // HTTP-Methode ist GET
    dataType: "json", // Erwartetes Datenformat ist JSON
    success: function (response) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      if (response.success) { // Überprüft, ob das Laden der Profilinformationen erfolgreich war
        // Füllt die Formularfelder mit den erhaltenen Daten
        $("#vorname").val(response.data.Vorname);
        $("#nachname").val(response.data.Nachname);
        $("#adresse").val(response.data.Adresse);
        $("#plz").val(response.data.Plz);
        $("#ort").val(response.data.Ort);
        $("#email").val(response.data.Mail);
        $("#zahlungsinformation").val(response.data.Zahlungsinformation);
      } else {
        console.error("Profil konnte nicht geladen werden:", response.error); // Loggt die Fehlermeldung, falls das Laden nicht erfolgreich war
      }
    },
    error: function (xhr, status, error) {
      console.error("Ein Fehler ist aufgetreten:", error); // Loggt technische Fehler
    },
  });
}

// Funktion zur Verifizierung des Passworts
function verifyPassword() {
  var password = $("#password").val(); // Holt das eingegebene Passwort aus dem Passwortfeld
  $.ajax({
    url: "/ArtShop/verifyPassword.php", // Der Pfad zum PHP-Skript, das das Passwort überprüft
    type: "POST", // HTTP-Methode ist POST
    data: { password: password }, // Sendet das Passwort als Daten an den Server
    dataType: "json", // Erwartetes Datenformat ist JSON
    success: function (response) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      console.log("Password verification response:", response); // Loggt die Antwort zur Konsole
      if (response.success) { // Überprüft, ob die Passwortüberprüfung erfolgreich war
        $("#passwordModal").modal("hide"); // Schließt das Passwort-Modal
        updateProfile(); // Ruft die Funktion zum Aktualisieren des Profils auf
      } else {
        alert("Falsches Passwort"); // Zeigt eine Warnung bei falschem Passwort
      }
    },
    error: function (xhr, status, error) {
      console.error("Ein Fehler ist aufgetreten:", error); // Loggt technische Fehler zur Konsole
      console.error("Response Text:", xhr.responseText); // Loggt den Antworttext zur Konsole für Debugging-Zwecke
    },
  });
}




/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//MEIN KONTO ÄNDERUNGEN///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Funktion zum Aktualisieren des Profils
function updateProfile() {
  var formData = $("#profileForm").serialize(); // Sammelt die Formulardaten und serialisiert sie in ein URL-kodiertes Format
  $.ajax({
    url: "/ArtShop/updateProfile.php", // Der Pfad zum PHP-Skript, das die Aktualisierungen speichert
    type: "POST", // HTTP-Methode ist POST
    data: formData, // Die serialisierten Formulardaten werden als Body der Anfrage gesendet
    dataType: "json", // Erwartetes Datenformat ist JSON
    success: function (response) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      if (response.success) { // Überprüft, ob das Aktualisieren des Profils erfolgreich war
        alert("Profil erfolgreich aktualisiert."); // Zeigt eine Erfolgsmeldung an
      } else {
        alert("Fehler beim Aktualisieren des Profils: " + response.error); // Zeigt eine Fehlermeldung an, falls das Aktualisieren nicht erfolgreich war
      }
    },
    error: function (xhr, status, error) {
      alert("Ein Fehler ist aufgetreten: " + error); // Zeigt eine allgemeine Fehlermeldung an, falls ein technischer Fehler auftritt
    },
  });
}
*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////KUNDENSTAMM ANZEIGEN///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// in kundenBearbeiten.html eingefügt
/*
$(document).ready(function() {
  // Lädt die Navbar
  $("#navbar-placeholder").load("/ArtShop/simpleJsonClient/config/navbar.php");

  // Kundenverwaltung (Customer Management)
  loadCustomers(); // Lädt die Liste der Kunden

  // Event-Listener für Deaktivieren/Aktivieren-Button in der Kundentabelle
  $('#customerTable').on('click', '.deactivate-button', function () {
      var userId = $(this).data('id'); // Holt die Benutzer-ID aus dem Button
      console.log("Deaktivieren/Aktivieren Button geklickt, Benutzer ID: " + userId);
      deactivateUser(userId); // Ruft die Funktion zum Deaktivieren/Aktivieren des Benutzers auf
  });

  // Event-Listener für Bestellungen-Button in der Kundentabelle
  $('#customerTable').on('click', '.orders-button', function () {
      var userId = $(this).data('id'); // Holt die Benutzer-ID aus dem Button
      console.log("Bestellungen Button geklickt, Benutzer ID: " + userId);
      loadOrders(userId); // Ruft die Funktion zum Laden der Bestellungen des Benutzers auf
  });

  // Event-Listener für Zeilen in der Bestelltabelle
  $('#orderTable').on('click', 'tr', function () {
      var orderId = $(this).data('id'); // Holt die Bestell-ID aus der Tabellenzeile
      console.log("Bestellung geklickt, Bestell-ID: " + orderId);
      loadOrderDetails(orderId); // Ruft die Funktion zum Laden der Bestelldetails auf
  });

  // Event-Listener für Produkt entfernen Button in der Bestelldetailtabelle
  $('#orderDetailsTable').on('click', '.remove-item-button', function () {
      var BID = $(this).data('bid'); // Holt die Bestell-ID aus dem Button
      var PID = $(this).data('pid'); // Holt die Produkt-ID aus dem Button
      console.log("Produkt entfernen Button geklickt, Bestell-ID: " + BID + ", Produkt-ID: " + PID);
      removeOrderItem(BID, PID); // Ruft die Funktion zum Entfernen des Produkts aus der Bestellung auf
  });
});


function loadCustomers() {
  $.ajax({
      url: '/ArtShop/getCustomers.php',
      type: 'GET',
      dataType: 'json',
      success: function (data) {
          var rows = "";
          console.log(data);
          data.forEach(function (customer) {
              rows += `<tr>
                  <td>${customer.KID}</td>
                  <td>${customer.Benutzername}</td>
                  <td class="${customer.Inaktiv == 1 ? 'status-deaktiviert' : 'status-aktiv'}">${customer.Inaktiv == 1 ? "Deaktiviert" : "Aktiv"}</td>
                  <td><button data-id="${customer.KID}" class="btn btn-sm deactivate-button">${customer.Inaktiv == 1 ? "Aktivieren" : "Deaktivieren"}</button></td>
                  <td><button data-id="${customer.KID}" class="btn btn-sm btn-info orders-button">Bestellungen</button></td>
              </tr>`;
          });
          $("#customerTable tbody").html(rows);
      },
      error: function(xhr, status, error) {
          console.error("Fehler beim Laden der Kunden: " + error);
          console.log(xhr.responseText);
      }
  });
}

function deactivateUser(userId) {
  $.ajax({
    url: '/ArtShop/deactivateCustomer.php', // Der Pfad zum PHP-Skript, das den Kundenstatus ändert
    type: 'POST', // HTTP-Methode ist POST
    data: { KID: userId }, // Sendet die Kunden-ID als Daten an den Server
    success: function (response) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      console.log("Kundenstatus geändert, Antwort: " + response); // Loggt die Antwort zur Konsole
      loadCustomers(); // Kundenliste neu laden
    },
    error: function(xhr, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      console.error("Fehler beim Ändern des Kundenstatus: " + error); // Loggt den Fehler zur Konsole
      console.log(xhr.responseText); // Loggt die Antwort des Servers zur Konsole für Debugging-Zwecke
    }
  });
}


function loadOrders(userId) {
  $.ajax({
    url: '/ArtShop/getOrdersfromCustomer.php', // Der Pfad zum PHP-Skript, das die Bestellungen eines Kunden abruft
    type: 'GET', // HTTP-Methode ist GET
    data: { KID: userId }, // Sendet die Kunden-ID als Daten an den Server
    dataType: 'json', // Erwartetes Datenformat ist JSON
    success: function (orders) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      console.log(userId); // Loggt die Kunden-ID zur Konsole
      if (orders.error) { // Überprüft, ob ein Fehler in der Antwort enthalten ist
        alert(orders.error); // Zeigt eine Fehlermeldung an
        return; // Beendet die Funktion
      }
      var rows = ''; // Initialisiert die Variable für die Tabellenzeilen
      orders.forEach(function (order) { // Schleife durch jede Bestellung
        rows += `<tr data-id="${order.BID}">
          <td>${order.BID}</td>
          <td>${order.Bestelldatum}</td>
          <td>${order.Gesamtsumme.toFixed(2)}</td>
          <td>${order.Zahlungsinformation}</td>
        </tr>`; // Fügt eine Tabellenzeile für jede Bestellung hinzu
      });
      $('#orderTable tbody').html(rows); // Fügt die Zeilen in den Tabellenkörper ein
      $('#orderModal').modal('show'); // Zeigt das Bestellungsmodal an
    },
    error: function(xhr, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      console.error("Fehler beim Laden der Bestellungen: " + error); // Loggt den Fehler zur Konsole
      console.log(xhr.responseText); // Loggt die Antwort des Servers zur Konsole für Debugging-Zwecke
    }
  });
}


function loadOrderDetails(orderId) {
  $.ajax({
    url: '/ArtShop/getOrderDetails.php', // Der Pfad zum PHP-Skript, das die Details einer Bestellung abruft
    type: 'GET', // HTTP-Methode ist GET
    data: { BID: orderId }, // Sendet die Bestell-ID als Daten an den Server
    dataType: 'json', // Erwartetes Datenformat ist JSON
    success: function (orderDetails) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      if (orderDetails.error) { // Überprüft, ob ein Fehler in der Antwort enthalten ist
        alert(orderDetails.error); // Zeigt eine Fehlermeldung an
        return; // Beendet die Funktion
      }
      var rows = ''; // Initialisiert die Variable für die Tabellenzeilen
      orderDetails.forEach(function (item) { // Schleife durch jede Bestellposition
        rows += `<tr>
          <td>${item.PID}</td>
          <td>${item.Menge}</td>
          <td>${item.Preis}</td>
          <td><button class="btn btn-sm btn-danger remove-item-button" data-bid="${orderId}" data-pid="${item.PID}">Entfernen</button></td>
        </tr>`; // Fügt eine Tabellenzeile für jede Bestellposition hinzu
      });
      $('#orderDetailsTable tbody').html(rows); // Fügt die Zeilen in den Tabellenkörper ein
      $('#orderDetailsModal').modal('show'); // Zeigt das Bestelldetailmodal an
    },
    error: function(xhr, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      console.error("Fehler beim Laden der Bestellpositionen: " + error); // Loggt den Fehler zur Konsole
      console.log(xhr.responseText); // Loggt die Antwort des Servers zur Konsole für Debugging-Zwecke
    }
  });
}


function removeOrderItem(BID, PID) {
  $.ajax({
    url: '/ArtShop/removeOrderItem.php', // Der Pfad zum PHP-Skript, das das Entfernen eines Produkts aus einer Bestellung verarbeitet
    type: 'POST', // HTTP-Methode ist POST
    data: { BID: BID, PID: PID }, // Sendet die Bestell-ID und Produkt-ID als Daten an den Server
    success: function (response) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      console.log("Produkt aus der Bestellung entfernt, Antwort: " + response); // Loggt die Antwort zur Konsole
      alert('Produkt erfolgreich aus der Bestellung entfernt.'); // Zeigt eine Erfolgsmeldung an
      loadOrderDetails(BID); // Bestellpositionen neu laden
      loadOrders($('#customerTable .orders-button').data('id')); // Bestellungen neu laden, um den aktualisierten Gesamtbetrag anzuzeigen
    },
    error: function(xhr, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      console.error("Fehler beim Entfernen des Produkts: " + error); // Loggt den Fehler zur Konsole
      console.log(xhr.responseText); // Loggt die Antwort des Servers zur Konsole für Debugging-Zwecke
    }
  });
}
*/

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//WARENKORB///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$(document).ready(function() {
  // Initiales Laden der Warenkorbartikel
  updateCartItems();

  // Event-Listener für die Änderung der Zahlungsmethode
  $('#payment_method').change(function() {
    if ($(this).val() == 'Gutschein') { // Wenn die Zahlungsmethode "Gutschein" ist
      $('#voucher-section').show(); // Zeige den Gutschein-Bereich
    } else {
      $('#voucher-section').hide(); // Verberge den Gutschein-Bereich
      $('#remainingAmount').hide(); // Verberge den verbleibenden Betrag
    }
  });

  // Event-Listener für den Klick auf den Gutschein-Anwenden-Button
  $('#apply-voucher').click(function() {
    console.log('Gutschein anwenden button clicked'); // Debugging-Ausgabe
    var voucherCode = $('#voucher_code').val(); // Holt den eingegebenen Gutscheincode
    console.log('Voucher code entered:', voucherCode); // Debugging-Ausgabe
    if (voucherCode) {
      applyVoucher(voucherCode); // Ruft die Funktion zur Anwendung des Gutscheins auf
    } else {
      alert('Bitte geben Sie einen Gutscheincode ein.'); // Zeigt eine Warnung an, wenn kein Gutscheincode eingegeben wurde
    }
  });

  // Event-Listener für den Klick auf den Checkout-Button
  $('#checkout-button').click(function() {
    // Checkout-Logik hier
    var totalPrice = parseFloat($("#totalPrice").data("total-price")); // Holt den Gesamtpreis
    var voucherAmount = parseFloat($("#voucher_amount").data("voucher-amount")) || 0; // Holt den Gutscheinbetrag oder 0, wenn kein Gutscheinbetrag vorhanden ist
    var remainingAmount = totalPrice - voucherAmount; // Berechnet den verbleibenden Betrag

    if (remainingAmount > 0) {
      $("#remainingAmount").text('Verbleibender Betrag: ' + remainingAmount.toFixed(2) + ' €').show(); // Zeigt den verbleibenden Betrag an
      // Logik hinzufügen, um den verbleibenden Betrag zu bezahlen
    } else {
      $("#remainingAmount").hide(); // Verbirgt den verbleibenden Betrag, wenn er 0 oder weniger ist
      // Logik hinzufügen, um die vollständige Bezahlung mit dem Gutschein zu handhaben
    }
  });

  // Initialer Trigger für die Zahlungsmethode, um den richtigen Zustand anzuzeigen
  $("#payment_method").trigger('change');
});

function addToCart(productId) {
  $.ajax({
    url: "../addToCart.php", // Der Pfad zum PHP-Skript, das das Hinzufügen zum Warenkorb verarbeitet
    type: "POST", // HTTP-Methode ist POST
    data: { product_id: productId }, // Sendet die Produkt-ID als Daten an den Server
    success: function(response) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      updateCartCount(); // Aktualisiert die Warenkorbanzahl
      updateCartItems(); // Aktualisiert die Warenkorbartikel
    },
    error: function(request, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      console.error("Error adding to cart:", error); // Loggt den Fehler zur Konsole
    }
  });
}


function updateCartCount() {
  $.ajax({
    url: "/ArtShop/cartCount.php", // Der Pfad zum PHP-Skript, das die Anzahl der Artikel im Warenkorb abruft
    type: "GET", // HTTP-Methode ist GET
    success: function(count) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      $("#cart-count").text(count); // Aktualisiert den Text des Elements mit der ID "cart-count" mit der erhaltenen Anzahl
    },
    error: function(request, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      console.error("Error fetching cart count:", error); // Loggt den Fehler zur Konsole
    }
  });
}

function updateCartItems() {
  $.ajax({
    url: "/ArtShop/getCartItems.php", // Der Pfad zum PHP-Skript, das die Artikel im Warenkorb abruft
    type: "GET", // HTTP-Methode ist GET
    dataType: "json", // Erwartetes Datenformat ist JSON
    success: function(cartItems) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      var tableBody = $("#cartTable tbody"); // Holt den Tabellenkörper der Warenkorbtabelle
      tableBody.empty(); // Leert den Tabellenkörper
      var totalPrice = 0; // Initialisiert den Gesamtpreis

      if (cartItems.length === 0) { // Überprüft, ob der Warenkorb leer ist
        tableBody.html("<tr><td colspan='6'>Ihr Warenkorb ist leer.</td></tr>"); // Zeigt eine Nachricht an, dass der Warenkorb leer ist
      } else {
        cartItems.forEach(function(item) { // Schleife durch jede Artikel im Warenkorb
          var itemTotal = item.Preis * item.Menge; // Berechnet den Gesamtpreis für diesen Artikel
          totalPrice += itemTotal; // Addiert den Artikelpreis zum Gesamtpreis

          var row = $("<tr>"); // Erzeugt eine neue Tabellenzeile
          row.append($("<td>").text(item.PID)); // Fügt die Produkt-ID hinzu
          row.append($("<td>").text(item.Bezeichnung)); // Fügt die Bezeichnung hinzu
          row.append($("<td>").html(`<input type="number" class="form-control" value="${item.Menge}" min="1" onchange="changeQuantity(${item.PID}, this.value)">`)); // Fügt ein Eingabefeld für die Menge hinzu
          row.append($("<td>").text(item.Preis.toFixed(2) + ' EUR')); // Fügt den Preis hinzu
          row.append($("<td>").text(itemTotal.toFixed(2) + ' EUR')); // Fügt den Gesamtpreis für diesen Artikel hinzu
          row.append($("<td>").html(`<button class="btn btn-danger" onclick="removeFromCart(${item.PID})">Entfernen</button>`)); // Fügt einen Button zum Entfernen des Artikels hinzu

          tableBody.append(row); // Fügt die Zeile zur Tabelle hinzu
        });
      }

      $("#totalPrice").text('Gesamtpreis: ' + totalPrice.toFixed(2) + ' €'); // Zeigt den Gesamtpreis an

      // Setzt den Gesamtpreis im Session
      setCartTotalInSession(totalPrice);
    },
    error: function(request, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      $("#cartTable tbody").html("<tr><td colspan='6'>Es gab ein Problem beim Laden des Warenkorbs.</td></tr>"); // Zeigt eine Fehlermeldung in der Tabelle an
      console.error("Error fetching cart items:", error); // Loggt den Fehler zur Konsole
    }
  });
}

function setCartTotalInSession(totalPrice) {
  $.ajax({
    url: '/ArtShop/setCartTotalInSession.php', // Der Pfad zum PHP-Skript, das den Gesamtpreis im Session speichert
    type: 'POST', // HTTP-Methode ist POST
    data: { total: totalPrice }, // Sendet den Gesamtpreis als Daten an den Server
    success: function(response) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      console.log('Cart total set in session: ', response); // Loggt die Antwort zur Konsole
    },
    error: function(request, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      console.error("Error setting cart total in session:", error); // Loggt den Fehler zur Konsole
    }
  });
}


function applyVoucher(voucherCode) {
  console.log('Applying voucher:', voucherCode); // Debugging-Ausgabe
  $.ajax({
    url: '/ArtShop/applyVoucher.php', // Der Pfad zum PHP-Skript, das den Gutschein anwendet
    type: 'POST', // HTTP-Methode ist POST
    data: { voucher_code: voucherCode }, // Sendet den Gutscheincode als Daten an den Server
    success: function(response) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      console.log('Voucher apply response:', response); // Debugging-Ausgabe
      if (response.success) { // Überprüft, ob der Gutschein erfolgreich angewendet wurde
        $("#voucher_amount").data("voucher-amount", response.discount); // Speichert den Gutscheinbetrag im Data-Attribut
        $("#totalPrice").data("total-price", response.newTotal); // Aktualisiert den Gesamtpreis im Data-Attribut
        alert('Gutschein erfolgreich angewendet. Betrag: ' + response.discount + ' €'); // Zeigt eine Erfolgsmeldung an
        $("#totalPrice").text('Gesamtpreis: ' + response.newTotal.toFixed(2) + ' €'); // Aktualisiert den angezeigten Gesamtpreis
      } else {
        alert(response.message); // Zeigt eine Fehlermeldung an, falls die Anwendung des Gutscheins fehlschlägt
      }
    },
    error: function(request, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      console.error("Error applying voucher:", error); // Loggt den Fehler zur Konsole
    }
  });
}


function changeQuantity(productId, newQuantity) {
  $.ajax({
    url: '/ArtShop/updateCartQuantity.php', // Der Pfad zum PHP-Skript, das die Menge eines Produkts im Warenkorb aktualisiert
    type: 'POST', // HTTP-Methode ist POST
    data: { product_id: productId, quantity: newQuantity }, // Sendet die Produkt-ID und die neue Menge als Daten an den Server
    success: function(response) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      updateCartItems(); // Aktualisiert die Warenkorbartikel
    },
    error: function(request, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      console.error("Error updating quantity:", error); // Loggt den Fehler zur Konsole
    }
  });
}



function removeFromCart(productId) {
  $.ajax({
    url: '/ArtShop/removeFromCart.php', // Der Pfad zum PHP-Skript, das das Entfernen eines Produkts aus dem Warenkorb verarbeitet
    type: 'POST', // HTTP-Methode ist POST
    data: { product_id: productId }, // Sendet die Produkt-ID als Daten an den Server
    success: function(response) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      updateCartItems(); // Aktualisiert die Warenkorbartikel
      updateCartCount(); // Aktualisiert die Warenkorbanzahl
    },
    error: function(request, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      console.error("Error removing item from cart:", error); // Loggt den Fehler zur Konsole
    }
  });
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////PRODUKTE BESTELLEN///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
  loadCartItems(); // Initiales Laden der Warenkorbartikel

  // Event-Listener für den Bestellbutton
  $("#checkout-button").click(function() {
    if (confirm("Möchten Sie die Bestellung aufgeben?")) { // Bestätigungsdialog anzeigen
      placeOrder(); // Aufgeben der Bestellung, wenn der Benutzer bestätigt
    }
  });

  // Event-Listener für die Zahlungsmethode
  $("#payment_method").change(function() {
    if ($(this).val() === 'Gutschein') { // Wenn die Zahlungsmethode "Gutschein" ist
      $("#voucher-section").show(); // Zeige den Gutschein-Bereich
    } else {
      $("#voucher-section").hide(); // Verberge den Gutschein-Bereich
    }
  });

  $("#payment_method").trigger('change'); // Initialer Trigger, um den richtigen Zustand anzuzeigen
});


function loadCartItems() {
  
  var cartItems = [];

  var $tbody = $("#cartTable tbody");
  $tbody.empty();

  cartItems.forEach(function(item) {
      var totalPrice = item.Menge * item.Preis;
      var $row = $("<tr>");
      $row.append($("<td>").text(item.PID));
      $row.append($("<td>").text(item.Bezeichnung));
      $row.append($("<td>").text(item.Menge));
      $row.append($("<td>").text(item.Preis.toFixed(2) + " €"));
      $row.append($("<td>").text(totalPrice.toFixed(2) + " €"));
      $tbody.append($row);
  });
}

function placeOrder() {
  var paymentMethod = $("#payment_method").val(); // Holt die gewählte Zahlungsmethode
  var voucherCode = $("#voucher_code").val(); // Holt den eingegebenen Gutscheincode
  var totalPrice = calculateTotalAmount(); // Berechnet den Gesamtbetrag der Warenkorbartikel
  var voucherAmount = parseFloat($("#voucher_amount").data("voucher-amount")) || 0; // Holt den Gutscheinbetrag oder 0, wenn keiner vorhanden ist
  var remainingAmount = totalPrice - voucherAmount; // Berechnet den verbleibenden Betrag

  $.ajax({
    url: "/ArtShop/process_order.php", // Der Pfad zum PHP-Skript, das die Bestellung verarbeitet
    method: "POST", // HTTP-Methode ist POST
    data: {
      payment_method: paymentMethod,
      voucher_code: voucherCode,
      total_amount: remainingAmount,
    },
    success: function (response) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      var result = JSON.parse(response);
      if (result.error) { // Überprüft, ob ein Fehler in der Antwort enthalten ist
        alert(result.error); // Zeigt die Fehlermeldung an
      } else {
        alert("Bestellung erfolgreich abgeschlossen: Bestellnummer: " + result.order_id); // Zeigt eine Erfolgsmeldung an
        // Warenkorb leeren und den Benutzer zur Startseite weiterleiten
        window.location.href = "/ArtShop/simpleJsonClient/index.html";
      }
    },
    error: function (xhr, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      var result = JSON.parse(xhr.responseText);
      alert(result.error || "Es gab ein Problem bei der Bestellung. Bitte versuchen Sie es erneut."); // Zeigt eine allgemeine Fehlermeldung an
    },
  });
}


function calculateTotalAmount() {
  var totalAmount = 0; // Initialisiert den Gesamtbetrag
  $("#cartTable tbody tr").each(function() { // Durchläuft jede Tabellenzeile im Tabellenkörper
    var rowTotal = parseFloat($(this).find("td").eq(4).text().replace(' €', '')); // Holt den Wert der fünften Zelle, entfernt das Währungssymbol und wandelt ihn in eine Zahl um
    totalAmount += rowTotal; // Addiert den Zeilenwert zum Gesamtbetrag
  });
  return totalAmount; // Gibt den Gesamtbetrag zurück
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////GUTSCHEINE///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//in GutscheineVerwalten.html drinnen
/*
$(document).ready(function () {
  loadCoupons(); // Lädt die vorhandenen Gutscheine beim Laden der Seite

  // Event-Listener für das Absenden des Gutscheinformulars
  $("#voucherForm").submit(function (e) {
    e.preventDefault(); // Verhindert das Standardverhalten des Formulars (Seiten-Neuladung)
    var formData = $(this).serialize(); // Serialisiert die Formulardaten

    $.ajax({
      url: "/ArtShop/generate_coupon.php", // Der Pfad zum PHP-Skript, das den Gutscheincode generiert
      type: "POST", // HTTP-Methode ist POST
      data: formData, // Sendet die serialisierten Formulardaten
      dataType: "json", // Erwartetes Datenformat ist JSON
      success: function (response) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
        if (response.success) {
          $("#voucherMessage").html(`<div class="alert alert-success">Gutscheincode erfolgreich generiert: ${response.code}</div>`); // Zeigt eine Erfolgsmeldung an
          loadCoupons(); // Lädt die Liste der Gutscheine neu
        } else {
          $("#voucherMessage").html(`<div class="alert alert-danger">Fehler beim Generieren des Gutscheincodes: ${response.error}</div>`); // Zeigt eine Fehlermeldung an
        }
      },
      error: function (xhr, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
        $("#voucherMessage").html(`<div class="alert alert-danger">Ein Fehler ist aufgetreten: ${error}</div>`); // Zeigt eine allgemeine Fehlermeldung an
      }
    });
  });
});

function loadCoupons() {
  $.ajax({
    url: "/ArtShop/list_coupons.php", // Der Pfad zum PHP-Skript, das die Liste der Gutscheine abruft
    type: "GET", // HTTP-Methode ist GET
    dataType: "json", // Erwartetes Datenformat ist JSON
    success: function (coupons) { // Funktion, die bei erfolgreicher Antwort aufgerufen wird
      var rows = ""; // Initialisiert die Variable für die Tabellenzeilen
      coupons.forEach(function (coupon) { // Schleife durch jede Gutschein
        rows += `<tr>
          <td>${coupon.Gutscheincode}</td>
          <td>${coupon.DatumVon}</td>
          <td>${coupon.DatumBis}</td>
          <td>${coupon.Wert}</td>
        </tr>`; // Erzeugt eine Tabellenzeile für jeden Gutschein
      });
      $("#voucherTable tbody").html(rows); // Fügt die Zeilen in den Tabellenkörper ein
    },
    error: function(xhr, status, error) { // Funktion, die bei einem Fehler aufgerufen wird
      console.error("Fehler beim Laden der Gutscheine: " + error); // Loggt den Fehler zur Konsole
      console.log(xhr.responseText); // Loggt die Antwort des Servers zur Konsole für Debugging-Zwecke
    }
  });
}
*/
