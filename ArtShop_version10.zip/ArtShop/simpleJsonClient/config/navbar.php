<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>Webshop</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW"
        crossorigin="anonymous"></script>
    <!--<script src="/ArtShop/simpleJsonClient/controller.js" type="text/javascript"></script>-->

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link rel="stylesheet" href="/ArtShop/css/style.css">
    <!-- Weitere Head-Inhalte -->
</head>

<body>

    <?php
    session_start();




    if (isset($_SESSION['user_id'])) {
        $loginText = 'Logout';
        $loginUrl = '/ArtShop/logout.php';
    } else {
        $loginText = 'Login';
        $loginUrl = '/ArtShop/simpleJsonClient/config/login.html';
    }

    ?>
    <nav class="navbar">
        
        <div class="navbar-container">
            <div class="shop-name">
                <a href="/ArtShop/simpleJsonClient/index.html">ArtShop</a>
            </div>

            <div class="navbar-search">
                <input type="text" id="product-search" placeholder="Produkte suchen...">
            </div>

            <div class="navbar-links">

            <?php
                if ((isset($_SESSION['admin']) && $_SESSION['admin'] == 0)||(!isset($_SESSION['admin']))) {
                    ?> <a id="cartlink" href="/ArtShop/simpleJsonClient/config/warenkorb.html">Warenkorb(<span
                    id="cart-count">0</span>)</a>
                    <?php
                }
                ?>

                <?php
                if (isset($_SESSION['admin']) && $_SESSION['admin'] == 0) {
                    ?><a id="kontolink" href="/ArtShop/simpleJsonClient/config/meinKonto.html">Mein Konto</a>
                    <?php
                }
                ?>

                <?php
                if (isset($_SESSION['admin']) && $_SESSION['admin'] == 1) {
                    ?><a id="kundenEditlink" href="/ArtShop/simpleJsonClient/config/kundenBearbeiten.html">Kunden
                        bearbeiten</a>
                        <a id="produktEditlink" href="/ArtShop/simpleJsonClient/config/produkteVerwalten.html">Produkte
                        bearbeiten</a>
                        <a id="produktEditlink" href="/ArtShop/simpleJsonClient/config/gutscheineVerwalten.html">Gutscheine verwalten</a>
                    <?php
                }

               
                ?>


                <a href="<?php echo $loginUrl; ?>">
                    <?php echo $loginText; ?>
                </a>



                <!--<img src="/Artshop/img/warenkorb.png" alt="Warenkorb" width="90" height="80">-->

            </div>
        </div>
    </nav>



</body>

</html>