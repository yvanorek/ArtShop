<?php
session_start();
header('Content-Type: application/json');
include("serviceHandler/dbaccess.php");



if (isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];

    // Prüfen, ob der Warenkorb in der Session gesetzt ist
    if (isset($_SESSION['cart'][$product_id])) {
        // Entfernen Sie das Produkt aus dem Warenkorb
        unset($_SESSION['cart'][$product_id]);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['error' => 'Product not in cart']);
    }
} else {
    echo json_encode(['error' => 'Invalid input']);
}
?>
