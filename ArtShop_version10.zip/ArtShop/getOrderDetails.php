<?php
include("serviceHandler/dbaccess.php");

header('Content-Type: application/json');

if (!isset($_GET['BID'])) {
    echo json_encode(['error' => 'Keine Bestell-ID angegeben.']);
    exit;
}

$BID = $_GET['BID'];

$sql = "SELECT PID, Menge, Preis FROM bestellposition WHERE BID = ?";
$stmt = $db->prepare($sql);
if (!$stmt) {
    echo json_encode(['error' => 'Fehler bei der Vorbereitung der Abfrage: ' . $db->error]);
    exit;
}
$stmt->bind_param("i", $BID);
$stmt->execute();
$result = $stmt->get_result();

$orderDetails = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $orderDetails[] = $row;
    }
    echo json_encode($orderDetails);
} else {
    echo json_encode([]);
}
$stmt->close();
$db->close();
?>
