<?php

include("serviceHandler/dbaccess.php");

// Stellen Sie sicher, dass category_id als Parameter gesetzt ist
if(isset($_GET['category_id'])) {
    $categoryId = $_GET['category_id'];

    // Produkt-Abfrage mit Kategorie-Filter
    $pro_sql = "SELECT * FROM produkte WHERE KatID = ?";
    $stmt = $db->prepare($pro_sql);
    $stmt->bind_param("i", $categoryId); // "i" steht für "integer"
    $stmt->execute();
    $result = $stmt->get_result();

    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }

    echo json_encode($products);
} else {
    echo json_encode(["error" => "Keine category_id angegeben"]);
}

$db->close();
?>