<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $total = filter_input(INPUT_POST, 'total', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    
    if ($total !== null) {
        $_SESSION['cart_total'] = $total;
        echo json_encode(['success' => true, 'total' => $total]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid total value.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
?>
