<?php
session_start();
include("serviceHandler/dbaccess.php");

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Bitte melden Sie sich an, um die Bestellungen einzusehen.']);
    exit;
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT BID, Gesamtsumme, Zahlungsinformation, Bestelldatum FROM bestellungen WHERE KID = ? ORDER BY Bestelldatum DESC";
$stmt = $db->prepare($sql);
if (!$stmt) {
    echo json_encode(['error' => 'Fehler bei der Vorbereitung der Abfrage: ' . $db->error]);
    exit;
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$orders = [];
while ($row = $result->fetch_assoc()) {
    $order_id = $row['BID'];
    
    $row['Gesamtsumme'] = round($row['Gesamtsumme'], 2);
    // Fetch order items
    $sql_items = "SELECT PID, Menge, Preis FROM bestellposition WHERE BID = ?";
    $stmt_items = $db->prepare($sql_items);
    if (!$stmt_items) {
        echo json_encode(['error' => 'Fehler bei der Vorbereitung der Abfrage: ' . $db->error]);
        exit;
    }
    $stmt_items->bind_param("i", $order_id);
    $stmt_items->execute();
    $result_items = $stmt_items->get_result();
    
    $items = [];
    while ($item = $result_items->fetch_assoc()) {
        $items[] = $item;
    }
    
    $row['items'] = $items;
    $orders[] = $row;
}

$stmt->close();
echo json_encode($orders);
?>
