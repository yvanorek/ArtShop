<?php
session_start(); // Sicherstellen, dass die Session gestartet wird


// Initialisiere den Warenkorb, falls dieser noch nicht gesetzt wurde
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Zähle die Anzahl der Produkte im Warenkorb und gebe sie zurück
echo count($_SESSION['cart']);
?>