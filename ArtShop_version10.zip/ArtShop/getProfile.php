<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Benutzer ist nicht eingeloggt.']);
    exit;
}

// Ersetzen Sie dies durch eine Abfrage an Ihre Datenbank
$user_id = $_SESSION['user_id'];

// Nehmen wir an, Sie haben eine Funktion getUserProfile, die die Daten aus der Datenbank lädt
$profile = getUserProfile($user_id);

if ($profile) {
    // Passen Sie die Daten an und verbergen Sie sensible Informationen
    $profile['Zahlungsinformation'] = '****' . substr($profile['Zahlungsinformation'], -4);
    
    echo json_encode(['success' => true, 'data' => $profile]);
} else {
    echo json_encode(['success' => false, 'error' => 'Profil konnte nicht geladen werden.']);
}

function getUserProfile($user_id) {
    include("serviceHandler/dbaccess.php");
    //global $db; // Verwenden Sie das globale $db-Objekt, das Ihre Datenbankverbindung darstellt
    $stmt = $db->prepare("SELECT * FROM user WHERE KID = ?");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}

?>


