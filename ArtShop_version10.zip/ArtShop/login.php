<?php
session_start();
include("serviceHandler/dbaccess.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
    $remember = filter_input(INPUT_POST, 'remember', FILTER_SANITIZE_STRING);

    $stmt = $db->prepare("SELECT * FROM user WHERE Benutzername = ? OR Mail = ?");
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        if ($user['Inaktiv'] == 1) {
            echo json_encode(['success' => false, 'error' => 'Ihr Konto ist inaktiv. Bitte kontaktieren Sie den Support.']);
        } elseif (password_verify($password, $user['Passwort'])) {
            $_SESSION['user_id'] = $user['KID'];
            $_SESSION['admin'] = $user['Admin'];
            $_SESSION['last_activity'] = time();

            // Prüfen, ob der Benutzer "Login merken" aktiviert hat
            if ($remember == "on") {
                setcookie("user_id", $user['KID'], time() + (86400 * 30), "/"); // 30 Tage gültig
                $_SESSION['remember'] = true;
            } else {
                $_SESSION['remember'] = false;
            }

            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Benutzername oder Passwort falsch.']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Benutzername oder Passwort falsch.']);
    }

    $stmt->close();
}
?>
