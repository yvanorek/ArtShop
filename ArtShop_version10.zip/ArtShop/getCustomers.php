<?php
session_start();
header('Content-Type: application/json');

// Stellen Sie sicher, dass nur Admins Zugriff haben
if (!isset($_SESSION['admin']) || $_SESSION['admin'] != '1') {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

include("serviceHandler/dbaccess.php");

$query = "SELECT KID, Benutzername, Inaktiv FROM user";
$result = $db->query($query);

$customers = [];
while ($row = $result->fetch_assoc()) {
    $customers[] = $row;
}

echo json_encode($customers);
?>
