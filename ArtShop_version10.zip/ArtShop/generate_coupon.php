<?php
include ("serviceHandler/dbaccess.php");

function generateRandomCode($length = 5) {
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomCode = '';
    for ($i = 0; $i < $length; $i++) {
        $randomCode .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomCode;
}

header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $value = $_POST['value'];
    $expiry_date = date('Y-m-d', strtotime($_POST['expiry_date']));
    $code = generateRandomCode();

    $sql = "INSERT INTO gutscheine (Gutscheincode, Wert, DatumBis) VALUES (?, ?, ?)";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("sds", $code, $value, $expiry_date);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'code' => $code]);
    } else {
        echo json_encode(['success' => false, 'error' => $stmt->error]);
    }
    
    $stmt->close();
}
$db->close();
?>
